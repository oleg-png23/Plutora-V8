package dev.mobilecode

import android.content.SharedPreferences
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

data class Line(val kind: String, val text: String)

data class Cfg(val url: String, val model: String, val key: String, val auto: Boolean) {
    companion object {
        fun from(p: SharedPreferences) = Cfg(
            p.getString("url", "https://api.openai.com/v1")!!, p.getString("model", "gpt-4o")!!,
            p.getString("key", "")!!, p.getBoolean("auto", false)
        )
    }
}

private const val SYSTEM = "You are a coding agent running on an Android phone. Work inside the workspace " +
    "with your tools: list_dir, read_file, write_file, edit_file, grep, fetch_url, bash. Read a file before " +
    "editing it, prefer small edit_file changes, and keep replies short."
private val RISKY = setOf("bash", "write_file", "edit_file")

/** Agent loop for any OpenAI-compatible /chat/completions API. Sessions persist to [store]. */
class Agent(private val tools: Tools, private val store: File) {
    private val http = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()
    private val history = runCatching { JSONArray(store.readText()) }.getOrDefault(JSONArray())
    var approve: suspend (String) -> Boolean = { true }

    private fun msg(r: String, c: String) = JSONObject().put("role", r).put("content", c)

    fun reset() { for (i in history.length() - 1 downTo 0) history.remove(i); store.delete() }

    /** Drop a half-finished tool round left behind by Stop, so the next request stays valid. */
    private fun repair() {
        while (history.length() > 0) {
            val m = history.getJSONObject(history.length() - 1)
            if (m.optString("role") == "tool" || m.has("tool_calls")) history.remove(history.length() - 1) else break
        }
    }

    fun replay(): List<Line> = buildList {
        for (i in 0 until history.length()) {
            val m = history.getJSONObject(i)
            when (m.optString("role")) {
                "user" -> add(Line("user", m.optString("content")))
                "assistant" -> {
                    val c = m.optString("content", "")
                    if (c.isNotBlank() && c != "null") add(Line("assistant", c))
                    m.optJSONArray("tool_calls")?.let { calls ->
                        for (j in 0 until calls.length()) {
                            val fn = calls.getJSONObject(j).getJSONObject("function")
                            add(Line("tool", "${fn.getString("name")} ${fn.optString("arguments")}"))
                        }
                    }
                }
                "tool" -> add(Line("tool", "-> " + m.optString("content").take(300)))
            }
        }
    }

    suspend fun send(text: String, cfg: Cfg, emit: (String, String) -> Unit) = withContext(Dispatchers.IO) {
        repair()
        if (history.length() == 0) {
            val rules = File(tools.root, "AGENTS.md").takeIf { it.exists() }?.readText().orEmpty()
            history.put(msg("system", SYSTEM + if (rules.isBlank()) "" else "\nProject rules:\n$rules"))
        }
        history.put(msg("user", text))
        try {
            repeat(25) {
                ensureActive()
                val body = JSONObject().put("model", cfg.model).put("messages", history).put("tools", tools.schema)
                val req = Request.Builder().url(cfg.url.trimEnd('/') + "/chat/completions")
                    .header("Authorization", "Bearer ${cfg.key}")
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                val res = http.newCall(req).execute().use { it.body?.string() ?: "" }
                val m = runCatching { JSONObject(res).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") }.getOrNull()
                if (m == null) { emit("err", res.take(500).ifBlank { "Empty response" }); return@withContext }
                history.put(m)
                val c = m.optString("content", "")
                if (c.isNotBlank() && c != "null") emit("assistant", c)
                val calls = m.optJSONArray("tool_calls") ?: return@withContext
                for (i in 0 until calls.length()) {
                    ensureActive()
                    val call = calls.getJSONObject(i)
                    val fn = call.getJSONObject("function")
                    val name = fn.getString("name")
                    val args = try { JSONObject(fn.optString("arguments", "{}")) } catch (e: Exception) { JSONObject() }
                    emit("tool", "$name $args")
                    val ok = name !in RISKY || cfg.auto || approve("$name $args")
                    val out = if (ok) tools.run(name, args) else "denied by user"
                    emit("tool", "-> " + out.take(300))
                    history.put(JSONObject().put("role", "tool").put("tool_call_id", call.getString("id")).put("content", out))
                }
            }
        } finally { store.writeText(history.toString()) }
    }
}
