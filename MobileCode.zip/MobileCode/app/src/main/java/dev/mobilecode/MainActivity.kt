package dev.mobilecode

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File

// One solid accent, high-contrast text in both themes, no gradients. Spacing uses only 8dp and 16dp.
private val Dark = darkColorScheme(
    primary = Color(0xFFFFA45C), onPrimary = Color(0xFF1A1000), background = Color(0xFF111111),
    surface = Color(0xFF111111), onSurface = Color(0xFFEDEDED), surfaceVariant = Color(0xFF242424),
    onSurfaceVariant = Color(0xFFD6D6D6), error = Color(0xFFFF8A80)
)
private val Light = lightColorScheme(
    primary = Color(0xFFB34700), onPrimary = Color.White, background = Color(0xFFFAF8F5),
    surface = Color(0xFFFAF8F5), onSurface = Color(0xFF1B1B1B), surfaceVariant = Color(0xFFECE8E2),
    onSurfaceVariant = Color(0xFF33302C), error = Color(0xFFB3261E)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light) {
                Surface(Modifier.fillMaxSize()) { App(this) }
            }
        }
    }
}

@Composable
fun App(ctx: Context) {
    val prefs = remember { ctx.getSharedPreferences("cfg", 0) }
    val tools = remember { Tools(File(ctx.filesDir, "workspace")) }
    val agent = remember { Agent(tools, File(ctx.filesDir, "session.json")) }
    val log = remember { mutableStateListOf<Line>().apply { addAll(agent.replay()) } }
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var job by remember { mutableStateOf<Job?>(null) }
    var pending by remember { mutableStateOf<Pair<String, CompletableDeferred<Boolean>>?>(null) }
    agent.approve = { t ->
        val d = CompletableDeferred<Boolean>()
        withContext(Dispatchers.Main) { pending = t to d }
        d.await()
    }

    Column(Modifier.fillMaxSize()) {
        TabRow(tab) { listOf("Chat", "Files", "Settings").forEachIndexed { i, n -> Tab(tab == i, { tab = i }, text = { Text(n) }) } }
        when (tab) {
            0 -> Chat(agent, log, prefs, scope, job) { job = it }
            1 -> Files(tools)
            else -> Settings(prefs)
        }
    }
    pending?.let { (t, d) ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text("Allow this action?") },
            text = { Text(t, fontFamily = FontFamily.Monospace, fontSize = 13.sp) },
            confirmButton = { TextButton({ d.complete(true); pending = null }) { Text("Allow") } },
            dismissButton = { TextButton({ d.complete(false); pending = null }) { Text("Deny") } }
        )
    }
}

@Composable
fun Chat(agent: Agent, log: SnapshotStateList<Line>, prefs: SharedPreferences, scope: CoroutineScope, job: Job?, setJob: (Job?) -> Unit) {
    val state = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    val busy = job != null
    LaunchedEffect(log.size) { if (log.isNotEmpty()) state.scrollToItem(log.size - 1) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Session", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            TextButton(enabled = !busy, onClick = { agent.reset(); log.clear() }) { Text("New session") }
        }
        if (log.isEmpty()) {
            Text(
                "Describe a task, for example: write a script that renames photos by date. Add an AGENTS.md file to the workspace to give the agent standing rules.",
                Modifier.weight(1f).padding(vertical = 8.dp), color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        } else {
            LazyColumn(Modifier.weight(1f), state = state, verticalArrangement = Arrangement.spacedBy(8.dp)) { items(log) { Entry(it) } }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), placeholder = { Text("Describe a task") })
            Button(enabled = busy || input.isNotBlank(), onClick = {
                if (busy) job?.cancel() else {
                    val t = input; input = ""; log.add(Line("user", t))
                    setJob(scope.launch {
                        try {
                            agent.send(t, Cfg.from(prefs)) { k, x -> scope.launch(Dispatchers.Main) { log.add(Line(k, x)) } }
                        } catch (e: CancellationException) { log.add(Line("err", "Stopped"))
                        } catch (e: Exception) { log.add(Line("err", e.message ?: "Request failed"))
                        } finally { setJob(null) }
                    })
                }
            }) { Text(if (busy) "Stop" else "Send") }
        }
    }
}

@Composable
fun Entry(l: Line) {
    val c = MaterialTheme.colorScheme
    when (l.kind) {
        "tool" -> Text(l.text, Modifier.fillMaxWidth().background(c.surfaceVariant, RoundedCornerShape(8.dp)).padding(8.dp),
            color = c.onSurfaceVariant, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        "user" -> Text(l.text, fontWeight = FontWeight.Bold, color = c.primary)
        "err" -> Text(l.text, color = c.error)
        else -> Text(l.text, color = c.onSurface)
    }
}

@Composable
fun Files(tools: Tools) {
    var open by remember { mutableStateOf<String?>(null) }
    val names = remember { tools.all() }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        val o = open
        if (o == null) {
            if (names.isEmpty()) Text("No files yet. Ask the agent to create something.")
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(names) { n -> TextButton({ open = n }) { Text(n, fontFamily = FontFamily.Monospace) } }
            }
        } else {
            TextButton({ open = null }) { Text("Back to files") }
            Text(tools.run("read_file", JSONObject().put("path", o)), Modifier.verticalScroll(rememberScrollState()),
                fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        }
    }
}

@Composable
fun Settings(prefs: SharedPreferences) {
    val c = remember { Cfg.from(prefs) }
    var u by remember { mutableStateOf(c.url) }
    var m by remember { mutableStateOf(c.model) }
    var k by remember { mutableStateOf(c.key) }
    var auto by remember { mutableStateOf(c.auto) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ u = "https://api.openai.com/v1" }) { Text("OpenAI") }
            OutlinedButton({ u = "https://openrouter.ai/api/v1" }) { Text("OpenRouter") }
        }
        OutlinedTextField(u, { u = it }, Modifier.fillMaxWidth(), label = { Text("Base URL") }, singleLine = true)
        OutlinedTextField(m, { m = it }, Modifier.fillMaxWidth(), label = { Text("Model") }, singleLine = true)
        OutlinedTextField(k, { k = it }, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation())
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Run file edits and commands without asking", Modifier.weight(1f))
            Switch(auto, { auto = it })
        }
        Button({ prefs.edit().putString("url", u).putString("model", m).putString("key", k).putBoolean("auto", auto).apply() }) { Text("Save") }
    }
}
