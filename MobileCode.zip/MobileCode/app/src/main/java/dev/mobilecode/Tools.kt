package dev.mobilecode

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

/** Sandboxed tools the agent can call. All paths are relative to the workspace root. */
class Tools(val root: File) {
    init { root.mkdirs() }

    private fun f(p: String): File {
        val x = File(root, p).canonicalFile
        require(x.path.startsWith(root.canonicalPath)) { "path outside workspace" }
        return x
    }

    val schema = JSONArray().apply {
        fun t(n: String, d: String, vararg a: String) {
            val props = JSONObject().apply { a.forEach { put(it, JSONObject().put("type", "string")) } }
            val params = JSONObject().put("type", "object").put("properties", props).put("required", JSONArray(a.toList()))
            put(JSONObject().put("type", "function").put("function",
                JSONObject().put("name", n).put("description", d).put("parameters", params)))
        }
        t("list_dir", "List entries in a directory ('.' for root)", "path")
        t("read_file", "Read a file with line numbers", "path")
        t("write_file", "Create or overwrite a file", "path", "content")
        t("edit_file", "Replace one exact occurrence of old text with new text", "path", "old", "new")
        t("grep", "Search all files for a regex pattern", "pattern")
        t("fetch_url", "Fetch a web page or API response as text", "url")
        t("bash", "Run a shell command in the workspace (30s timeout)", "command")
    }

    fun run(name: String, a: JSONObject): String = try {
        when (name) {
            "list_dir" -> f(a.optString("path", ".")).listFiles()?.sortedBy { it.name }
                ?.joinToString("\n") { if (it.isDirectory) it.name + "/" else it.name } ?: "not a directory"
            "read_file" -> f(a.getString("path")).readLines()
                .mapIndexed { i, l -> "${i + 1}: $l" }.joinToString("\n").take(20000)
            "write_file" -> { val x = f(a.getString("path")); x.parentFile?.mkdirs(); x.writeText(a.getString("content")); "wrote ${x.name}" }
            "edit_file" -> {
                val x = f(a.getString("path")); val s = x.readText(); val o = a.getString("old")
                require(s.split(o).size == 2) { "old text must match exactly once" }
                x.writeText(s.replace(o, a.getString("new"))); "edited ${x.name}"
            }
            "grep" -> { val re = Regex(a.getString("pattern"))
                root.walkTopDown().filter { it.isFile }.flatMap { file ->
                    file.readLines().withIndex().filter { re.containsMatchIn(it.value) }
                        .map { "${file.relativeTo(root)}:${it.index + 1}: ${it.value}" }
                }.take(100).joinToString("\n").ifEmpty { "no matches" } }
            "bash" -> {
                val p = ProcessBuilder("sh", "-c", a.getString("command")).directory(root).redirectErrorStream(true).start()
                var out = ""
                val th = Thread { out = p.inputStream.bufferedReader().readText() }.apply { start() }
                if (!p.waitFor(30, TimeUnit.SECONDS)) { p.destroyForcibly(); "timeout" } else { th.join(); out.take(10000) }
            }
            "fetch_url" -> OkHttpClient().newCall(Request.Builder().url(a.getString("url")).build())
                .execute().use { it.body?.string().orEmpty().take(12000) }
            else -> "unknown tool $name"
        }
    } catch (e: Exception) { "error: ${e.message}" }

    fun all(): List<String> = root.walkTopDown().filter { it.isFile }.map { it.relativeTo(root).path }.sorted().toList()
}
