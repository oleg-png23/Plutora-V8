# MobileCode
A native Kotlin and Jetpack Compose coding agent for Android, inspired by OpenCode.

1. Open this folder in Android Studio and let Gradle sync (it generates the wrapper).
2. Run on a device or emulator (Android 8.0+).
3. Settings tab: pick OpenAI or OpenRouter (or type any OpenAI-compatible URL, such as an Ollama server on your network), then enter a model name and API key.
4. Chat tab: describe a task. The agent works in a sandboxed workspace with list_dir, read_file, write_file, edit_file, grep, fetch_url and bash.
5. File edits and commands ask for approval unless you turn that off in Settings. Stop cancels a running task.
6. Files tab: browse what the agent wrote. Put an AGENTS.md in the workspace to give it standing rules.
7. Sessions persist between launches. New session clears them.
